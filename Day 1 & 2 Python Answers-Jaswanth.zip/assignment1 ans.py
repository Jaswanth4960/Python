#1
'''
print("Calculating Area of Circle")
import math
r=int(input("Enter Circle Radius : "))
area=math.pi*r*r
print(area)

'''
#2
'''
print("Calculating Area of Rectangle ")
l=int(input("Enter length of rectangle :"))
b=int(input("Enter Breadth of rectangle :"))
Area=l*b;
print("Area of rectangle :",Area)
'''
#3
'''

passmark=35
marks_obtained=int(input("Enter the mark :"))
if marks_obtained>=passmark:
   print("Result : PASS")
else:
   print("Result : FAIL")
'''
#4
'''
s=input("Enter the expression :")
print(eval(s))
'''
#5
'''
print("Calculating Perimeter of Traingle")
a=int(input("Enter a :"))
b=int(input("Enter b :"))
c=int(input("Enter c :"))
if a+b>c and b+c>a and c+a>b:
    perimeter=a+b+c
    print("Perimeter of `triangle is :",perimeter)
else:
    print("Invalid Triangle")
'''
#6
'''
print("Finding Even or Odd")
n=int(input("Enter number :"))
if n==0:
    print(n," : is neither even nor odd number")
elif n%2==0:
    print(n," : is even number")
else:
    print(n," : is odd number")
'''
#7
'''
print("Finding Leap Year")
year=int(input("Enter Year : "))
if year%4==0 or year%100==0:
    print(year," is leap year")
else:
    print(year,"is not a leap year")
'''
#8
'''
m=ord('A')
n=ord('Z')
while m<=n:
    c=chr(m)
    print(c,"--",m)
    m=m+1
'''
#9
'''
m=ord('a')
n=ord('z')
while m<=n:
    c=chr(m)
    print(c,"--",m)
    m=m+1
'''
#10
'''
m=ord('0')
n=ord('9')
while m<=n:
    c=chr(m)
    print(c,"--",m)
    m=m+1
'''    

 

    





