#aadhar card
'''
import re
n=input('Enter your AADHAR Number :')
obj=re.fullmatch('\d{4}\s{1}\d{4}\s{1}\d{4}',n)
if obj!=None:
    print("Valid AADHAR Number")
else:
    print("Invalid AADHAR")
'''
#passport
'''
import re
p=input("Enter your Passport Number :")
obj=re.fullmatch('[A-Z]{1}[0-9]{7}',p)
if obj!=None:
    print("Valid Passport")
else:
    print("Invalid Passport")
'''
#car
'''
import re
print("Validating Vehicle Number: ")
n=input("Enter Vehicle Number :")
obj=re.fullmatch('[A-Z]{2}\s[0-49]{2}\s[A-Z]{2}\s[0-9]{4}',n)
if obj!=None:
    print("Valid Vehicle Number")
else:
    print("Invalid Vehicle Number")
'''
#Postalcode
'''
import re
p=input("Enter PostalCode:")
obj=re.fullmatch('[1-8]{1}\d{5}',p)
if obj!=None:
    print("Valid PostalCode")
else:
    print("Invalid Postalcode")
'''
#GST
'''
import re
gst=input("Enter GSTIN Identification Number :")
obj=re.fullmatch('\d{2}[A-Z]{5}[0-9]{4}[A-Z]{1}\d{1}Z{1}\d{1}',gst)
if obj!=None:
    print("Valid GSTIN")
else:
    print("Invalid GSTIN")
'''
#Pancard
'''
import re
pan=input("Enter PAN Card Number :")
obj=re.fullmatch("[A-Z]{5}\d{4}[A-Z]{1}",pan)
if obj!=None:
    print("Valid PAN")
else:
    print("Invalid PAN")
'''
#Greatest of Four numbers
'''
a=int(input())
b=int(input())
c=int(input())
d=int(input())
print(a if a>b and a>c and a>d else b if b>c and b>d else c if c>d else d)
'''

#Least of Four Numbers
'''
a=int(input())
b=int(input())
c=int(input())
d=int(input())
print(a if a<b and a<c and a<d else b if b<c and b<d else c if c<d else d)
'''
#Bitwise Operators
'''
a=16
b=20
c=a&b
d=a|b
print(c)
print(d)
'''
'''
a=25
b=15
c=a&b
d=a|b
print(c)
print(d)
'''
'''
a=30
b=13
c=a&b
d=a|b
print(c)
print(d)
'''
'''
a=15
b=3
c=a>>b
d=a<<b
print(c)
print(d)
'''
'''
a=25
b=4
c=a>>b
d=a<<b
print(c)
print(d)
'''
#ReverseFirstLastName
'''
firstname=input("Enter FirstName :")
lastname=input("Enter LastName :")
firstname,lastname=lastname,firstname
print('fullname :',firstname,'',lastname)
'''
#n+nn+nnn
'''
n=int(input("Enter Number :"))
nn=n*10+n
nnn=n*100+n*10+n
print(n+nn+nnn)
'''

'''
import os
os.getcwd()
'''
#swap
'''
a=input("a:")
b=input("b:")
a,b=b,a
print("a:",a)
print("b:",b)
'''
'''
import os
print(help(os))
'''
'''
import re
file_name = "abc.py"
file_extension = re.search(r"\.(.+)$", file_name).group(1)
print("File extension:", file_extension)
'''

























