'''
class University:
    def __init__(self):
        print("University")
    class Department:
        def __init__(self):
            print("Department")
        class Staff:
            def __init__(self):
                print("Staff")
            class Student:
                def __init__(self):
                    print("Student")
                    
u=University()
d=u.Department()
s=d.Staff()
st=s.Student()
'''
'''
class Employee:
    def getEmployee(self):
        self.name=input("Enter Employee Name :")
        self.eno=int(input("Enter Employee No: "))
        self.bp=int(input("Enter Basic Pay :"))
    def callAllowances(self):
        self.hra=0.05*self.bp
        self.ma=0.01*self.bp
        self.ta=0.15*self.bp
        self.pf=0.20*self.bp
        self.lic=0.12*self.bp
        self.itax=0.09*self.bp
        self.gp=self.bp+self.hra+self.ma+self.ta
        self.np=self.gp-(self.pf+self.lic+self.itax)
    def printDetails(self):
        print("Employee Name :",self.name)
        print("Emp no :",self.eno)
        print("Basic Pay:",self.bp)
        print("HRA :",self.hra)
        print("MA :",self.ma)
        print("TA :",self.ta)
        print("PF :",self.pf)
        print("LIC :",self.lic)
        print("ITAX :",self.itax)
        print("Gross Pay:",self.gp)
        print("Net Pay :",self.np)
e=Employee()
e.getEmployee()
e.callAllowances()
e.printDetails()
'''


    
        
