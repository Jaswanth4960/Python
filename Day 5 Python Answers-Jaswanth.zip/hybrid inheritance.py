
# Example for Hybrid inheritance: (Assignment)
#--------------------------------

#Combination of multiple and multilevel

class stud:
    def setstud(self,sno,sname):
        self.sno = sno;
        self.sname = sname;
        
    def putstud(self):
        print("Student No : " ,self.sno);
        print("Student Name : ",self.sname);
       
class marks(stud):
    def setmarks(self, m1,m2):
        self.mark1 = m1;
        self.mark2 = m2;
       
    def putmarks(self):
        print("Mark1 : " , self.mark1);
        print("Mark2 : " , self.mark2);

class pratical:
    def getpractial(self,p1):
        self.p1=p1;

    def putpractial(self):
        print("Practial mark=",self.p1);
    

       
class result(marks,pratical): # Multiple inheritance + Multilevel 
    def calc(self):
        self.total = self.mark1 + self.mark2+self.p1;
       
    def puttotal(self):
        print("Total : " , self.total);

r =result();
r.setstud(40,"Kiran");
r.setmarks(50,60);
r.getpractial(100);
r.calc();
r.putstud();
r.putmarks();
r.putpractial()
r.puttotal();
