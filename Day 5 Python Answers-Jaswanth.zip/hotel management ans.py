import random
class StarHotel:
    def getCustomer(self):
        self.name=input("Enter Customer Name :")
        self.age=int(input("Enter Age :"))
        self.contactnum=int(input("Enter Phone Number :"))
        self.aadharno=int(input("Enter AAdhar Number: "))
        

    def putCustomer(self):
        print("Customer Name :",self.name)
        print("Age :",self.age)
        print("Phone Number :",self.contactnum)
        print("Aadhar No :",self.aadharno)


    def gameBill(self,noofhrs,bill):
        print("Your gamebill was :",bill*noofhrs)
        return bill*noofhrs

    def laundryBill(self,shirts,pants):
        self.sl=150
        self.pl=200
        self.shirts=shirts
        self.pants=pants
        print("Your Total Laundry bill:",self.shirts*self.sl+self.pants*self.pl)
        return self.sl*self.shirts+self.pants*self.sl
    
    def restarauntBill(self,quantity):
        self.cost=250
        self.quantity=quantity
        print("Total Food Bill :",self.cost*self.quantity)
        return self.cost*self.quantity

s=StarHotel()
        
choice='Y'
one=5
two=8
three=10
four=10
while choice=='Y':
    print("------------------------Welcome to Xyenta Star Hotel--------------------")
    print("Please Choose Your Options :")
    print("1. Book Your Room")
    print("2. Check out")
    n=int(input("Please Enter your Request :"))

    if n==1:
        print("Please Enter your Details")
        s.getCustomer()
        roomtype=int(input("Enter type of sharing :"))
        if roomtype==1 and one>0:
            print("Your Room is Booked")
            roomrent=20000
            r=random.randint(100,104)
            print("Your Room No is :",r)
            one-=1
            choice='N'
            print("Here are the Keys!!")
        elif roomtype==2 and two>0:
            print("Your Room is Booked")
            
            roomrent=150000
            r=random.randint(200,207)
            print("Your Room No is :",r)
            two-=1
            choice='N'
            print("Here are the Keys!!")
        elif roomtype==3 and three>0:
            print("Your Room is Booked")
            roomrent=100000
            three-=1
            r=random.randint(300,309)
            print("Your Room No is :",r)
            choice='N'
            print("Here are the Keys!!")
        elif roomtype==4 and four>0:
            print("Your Room is Booked")
            roomrent=70000
            four-=1
            r=random.randint(400,409)
            print("Your Room No is :",r)
            choice='N'
            print("Here are the Keys!!")
        else:
            print(" Sorry Such Rooms are not Available")
            break          
    else:
        nc='Y'
        while nc=='Y':
            
            print("1.Check your GameBill")
            print("2.Check your Laundry Bill")
            print("3.Check your Restaraunt Bill")
            print("4.Total Bill")
            m=int(input("Please select your Bills to Pay:"))
      
            if m==1:
                game=input("Game you played :")
                hrs=int(input("No of hrs played :"))
                bill=int(input("Bill per hour :"))
                s.gameBill(hrs,bill)
                choice='N'
                nc=='Y'
            elif m==2:
                shirts=int(input("No of Shirts : "))
                pants=int(input("No of Pants :"))
                s.laundryBill(shirts,pants)
                choice='N'
                nc=='Y'
            elif m==3:
                bir=int(input("No of Biryanis :"))
                s.restarauntBill(bir)
                choice='N'
                nc=='Y'
            elif m==4:
                game=input("Game you played :")
                hrs=int(input("No of hrs played :"))
                bill=int(input("Bill per hour :"))
                g=s.gameBill(hrs,bill)
                shirts=int(input("No of Shirts : "))
                pants=int(input("No of Pants :"))
                l=s.laundryBill(shirts,pants)
                bir=int(input("No of Biryanis :"))
                r=s.restarauntBill(bir)
                r=int(input("Room Type :"))
                if r==1:
                    roomrent=200000
                elif r==2:
                    roomrent=150000
                elif r==3:
                    roomrent=100000
                elif r==4:
                    roomrent=70000
                else:
                    break
                totalbill=g+l+r+roomrent
                print("Your Total Bill :",totalbill)
                print("Payment was Successful!")
                print("Please visit us Again!")
                choice='N'
                nc=='N'
                break
            else:
                break
                print("Thank You")
                choice='N'
        

        


            
