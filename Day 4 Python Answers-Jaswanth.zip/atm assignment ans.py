# Python ATM Banking Example

print('Welcome to HDFC Bank ATM')
restart=('Y')
chances = 3
balance = 8000
while chances >= 0:
    pin = int(input('Please Enter You 4 Digit Pin: '))
    if pin == (1234):
        print('You entered you pin Correctly\n')
        print("Please Choose Your Language :")
        lan=input("Enter your language :")
        if lan in('ENGLISH','English','english'):
            restart='Y'
        else:
            print("Invalid Language.Please try again")
            break
        print("Please select your Account Type 1 - Saving 2- Current")
        n=int(input("Enter Account Type :"))
        if n==2:
            restart='Y'
        else:
            print("Invalid Account Type(1 or 2) :")
            break
        while restart not in ('n','NO','no','N'):
            print('Please Press 1 For Your Balance\n')
            print('Please Press 2 To Make a Withdrawl\n')
            print('Please Press 3 To Pay in\n')
            print('Please Press 4 To Return Card\n')
            option = int(input('What Would you like to choose?'))
            if option == 1:
                print('Your Balance is ,balance',balance)
                restart = input('Would You you like to go back? ')
                if restart in ('n','NO','no','N'):
                    print('Thank You')
                    restart=('y')
                    break
            elif option == 2:
                option2 = ('y')
                withdrawl = float(input('How Much Would you like to withdraw?  '))
                
                if withdrawl in [1000, 2000, 3000, 4000, 5000, 10000]:
                    if withdrawl>balance:
                        print("CANT PROCEED WITH YOUR TRANSACTION")
                        break
                elif withdrawl<=balance:
                    balance = balance - withdrawl
                    print ('\nYour Balance is now',balance)
                    restart = input('Would You you like to go back? ')
                    if restart in ('n','NO','no','N'):
                                    print('Thank You')
                                    break
                    elif withdrawl != [10, 20, 40, 60, 80, 100]:
                                print('Invalid Amount, Please Re-try\n')
                                restart = ('y')
                    elif withdrawl == 1:
                                withdrawl = float(input('Please Enter Desired amount:'))    

            elif option == 3:
                Pay_in = int(input('How Much Would You Like To Pay In? '))
                balance = balance + Pay_in
                print ('\nYour Balance is now ',balance)
                restart = input('Would You you like to go back? ')
                if restart in ('n','NO','no','N'):
                    print('Thank You')
                    break
            elif option == 4:
                print('Please wait whilst your card is Returned...\n')
                print('Thank you for you service')
                break
            else:
                print('Please Enter a correct number. \n')
                restart = ('y')
                
    elif pin != ('1234'):
        print('Incorrect Password')
        chances = chances - 1
        if chances == 0:
            print('\nNo more tries')
            break
