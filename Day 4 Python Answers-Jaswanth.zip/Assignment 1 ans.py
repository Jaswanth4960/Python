#1. Write a Python function to find the Max of three numbers.
'''
def maxThree(a,b,c):
    if a>b and a>c:
        print(a," is greater")
    elif b>c:
        print(b," is greater")
    else:
        print(c," is greater")
a=int(input("Enter a:"))
b=int(input("Enter b:"))
c=int(input("Enter c:"))
maxThree(a,b,c)
'''

'''2. Write a Python function to sum all the numbers in a list. 
Sample List : [8, 2, 3, 0, 7]
Expected Output : 20

l=[]
n=int(input("Enter no of Elements :"))
sum=0
for i in range(1,n+1):
    m=int(input())
    l.append(m)
for x in l:
    sum=sum+x
print("sum is ",sum)
'''


'''3. Write a Python program to reverse a string. 
Sample String : "1234abcd"
Expected Output : "dcba4321"

s=input("Enter String :")
l=list(s)
rl=list(reversed(l))
rs=''
for x in rl:
    rs=rs+x
print("Reversed String :",rs)
'''
    
    

'''4. Write a Python function that accepts a string and calculate the number of upper case letters and lower case letters. 
Sample String : 'The quick Brow Fox'
Expected Output :
No. of Upper case characters : 3
No. of Lower case Characters : 12

s=input("Enter String :")
u=0
l=0
for x in s:
    if x.isupper():
        u+=1
    else:
        l+=1
print("No of Uppercase Characters :",u)
print("No of Lowercase Characters :",l)
'''

'''
5. Write a Python function that takes a list and returns a new list with unique elements of the first list. 
Sample List : [1,2,3,3,3,3,4,5]
Unique List : [1, 2, 3, 4, 5]'''
'''
l=[]
n=int(input("Enter Number of Elements :"))
for i in range(1,n+1):
    m=int(input())
    l.append(m)
ul=list(set(l))
print(ul)
'''

'''
6. Write a Python function that takes a number as a parameter and check the number is prime or not.
'''
'''
def checkPrime(n):
    c=0
    for i in range(2,int(n/2)):
        if n%i==0:
            c=1
            break
        else:
            c=0
    if c==0:
        print(n," is prime")
    else:
        print(n,"is not a prime")
    
a=int(input("enter number :"))    
checkPrime(a)
'''

'''

7. Write a Python program to print the even numbers from a given list. 
Sample List : [1, 2, 3, 4, 5, 6, 7, 8, 9]
Expected Result : [2, 4, 6, 8]
'''
'''
l=[]
n=int(input("enter no of elements :"))
for i in range(1,n+1):
    m=int(input())
    l.append(m)
for x in l:
    if x%2!=0:
        l.remove(x)
print(l)
'''
'''

8. Write a Python function that checks whether a passed string is palindrome or not.
'''
'''
def reverseString(s):
    rl=list(reversed(list(s)))
    rs=''.join(rl)
    if rs==s:
        print(s," is palindrome")
    else:
        print(s," is not a palindrome")
    
a=input("Enter String :")
reverseString(a)
    '''
'''

9. Write a Python program that accepts a hyphen-separated sequence of words as input and prints the words in a hyphen-separated sequence after sorting them alphabetically.
Sample Items : green-red-yellow-black-white
Expected Result : black-green-red-white-yellow
'''
'''
def hypen(s):
    s=input("enter string :")
    os=''
    l=[]
    l=s.split('-')
    l.sort()
    os='-'.join(l)
    print(os)
a=input("Enter String :")
hypen(a)
'''
'''

10. Write a Python function to create and print a list where the values are square of numbers between 1 and 30 (both included).'''
'''
def SquareNum(n):
    l=[]
    for i in range(1,n+1):
        l.append(i*i)
    print(l)
SquareNum(30)
'''

