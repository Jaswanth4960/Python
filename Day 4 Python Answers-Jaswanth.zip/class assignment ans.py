#Employee Class
'''
class Employee:
    def getdata(self):
        self.name=input("Enter employee name :")
        self.empno=int(input("Enter empno :"))
        self.sal=int(input("Enter Salary: "))
    def calSal(self):
        self.hra=0.15*self.sal
        self.da=0.10*self.sal
        self.ta=self.hra+self.da
        print("Employee Name :",self.name)
        print("Employee Number : ",self.empno)
        print("Salary is : ",self.sal)
        print("hra : ",self.hra)
        print("da : ",self.da)
        print("ta : ",self.ta)
obj=Employee()
obj.getdata()
obj.calSal()
'''
'''
class Department:
    def putdata(self,deptno,dname,loc,tl):
        self.deptno=deptno
        self.dname=dname
        self.loc=loc
        self.tl=tl
    def getdata(self):
        print("Department Name : ",self.dname)
        print("Department Number : ",self.deptno)
        print("Location : ",self.loc)
        print("Team Lead :",self.tl)
obj=Department()
obj.putdata(20,'chem','hyd','john')
obj.getdata()
'''
'''
class Customer:
    def getCustomer(self):
        self.cname=input("Enter Customer Name : ")
        self.accno=int(input("Enter Acc No :"))
        self.balance=int(input("Enter Balance :"))
        self.ttype=input("Enter Transaction Type : ")
    def printCustomer(self):
        print("Customer Name - ",self.cname)
        print("Acc No -",self.accno)
        print("Balance - ",self.balance)
        print("Ttype - ",self.ttype)
obj=Customer()
obj.getCustomer()
obj.printCustomer()
'''
