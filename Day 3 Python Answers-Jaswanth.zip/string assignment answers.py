#All 'A' replace with '$'
'''
s1=input("Enter string :")
s2=s1.replace('a','$')
print(s2)
'''

#Remove nth character
'''
s=input("Enter String :")
n=int(input("Enter Index: "))
s1=s[:n]+s[n+1:]
print(s1)
'''

#Exchange first and last letter
'''
s=input("Enter String :")
s1=s[-1]+s[1:len(s)-1]+s[0]
print(s1)
'''

#Count vowels
'''
s=input("Enter String :")
c=0
for x in s:
    if x in('a','e','i','o','u','A','E','I','O','U'):
        c+=1
print(c)
'''
#Replace space with Hyphen
'''
s=input("Enter String :")
s1=s.replace(' ','-')
print(s1)
'''

#Calculate length of string without len function
'''
s=input("Enter string")
c=0
for x in s:
    c+=1
print(c)
'''

#Even index
'''
s=input("Enter String :")
even=s[::2]
print(even)
'''

#Length of characters/No of Words
'''
s=input("Enter String :")
l=s.split(' ')
print("no of words :",len(l))
print("no of characters",len(s))
'''

#Print count of lowercase characters
'''
s=input("Enter string :")
c=0
for x in s:
    if x.islower():
     c+=1
print(c)
'''

#palindrome
'''
s=input("Enter string :")
s1=reversed(s)
if s==s1:
    print(s," is palindrome")
else:
    print(s," is not a palindrome")
'''


#within 100 of 1000 or 2000
'''
n=int(input("Enter Number :"))
if n>=900 and n<=1100 or n>=1900 and n<=2100:
    print("Yes")
else:
    print("No")
'''
#Convert list to a string
'''
l=[]
n=int(input("Enter no of elements :"))
for i in range(1,n+1):
    m=input()
    l.append(m)
s=''
for x in l:
    s=s+x
print(s)
'''

#GCD
'''
x=int(input("Enter x:"))
y=int(input("Enter y:"))
if x > y:
    small = y
else:
    small = x
for i in range(1, small + 1):
    if((x % i == 0) and (y % i == 0)):
        gcd = i
print("gcd is :",gcd)
'''

			






