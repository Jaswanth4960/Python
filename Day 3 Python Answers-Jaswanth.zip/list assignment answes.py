#List assignment
#Add Elements
'''
print("Add elements of List")
n=int(input("Enter no of elements :"))
l=[]
for i in range(1,n+1):
    m=int(input("Enter Element:"))
    l.append(m)
sum=0
for x in l:
    sum=sum+x
print(sum)
'''
#Multiply elements
'''
print("Multiply elements of List")
n=int(input("Enter no of elements :"))
l=[]
for i in range(1,n+1):
    m=int(input("Enter Element:"))
    l.append(m)
mul=1
for x in l:
    mul=mul*x
print("Result :",mul)
'''
#Greatest Number
'''
l=[]
n=int(input("Enter no of elements :"))
for i in range(1,n+1):
    m=int(input("Enter Element:"))
    l.append(m)
l.sort()
print(l[-1])
'''
#Smallest Number
'''
l=[]
n=int(input("Enter no of elements :"))
for i in range(1,n+1):
    m=int(input("Enter Element:"))
    l.append(m)
l.sort()
print(l[0])
'''
#Empty List
'''
l=[]
n=int(input("Enter no of elements :"))
for i in range(1,n+1):
    m=int(input("Enter Element:"))
    l.append(m)
if len(l)==0:
    print("List is Empty")
else:
    print("List is not Empty")
'''
#Print Even Numbers in List
l=[]
n=int(input("Enter no of elements :"))
for i in range(1,n+1):
    m=int(input())
    l.append(m)
for x in l:
    if x%2==0:
        print(x,end=" ")
