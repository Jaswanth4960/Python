#!/usr/bin/env python
# coding: utf-8

# In[7]:


import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD1',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD1")
sql="select * from actor"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from actor")
query="insert into ACTOR values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[8]:


#DVDSTAGING- CATEGORY
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD1',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD1")
sql="select * from category"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from category")
query="insert into category values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[9]:


#DVDSTAGING- City
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD1',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD1")
sql="select * from city"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from city")
query="insert into city values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[10]:


#DVDSTAGING- Country
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD1',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD1")
sql="select * from country"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from country")
query="insert into country values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[11]:


#DVDSTAGING- Language
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD1',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD1")
sql="select * from language"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from language")
query="insert into language values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[12]:


#DVDSTAGING- film
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from film"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from film")
query="insert into film values(?,?,?,?,?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[13]:


#DVDSTAGING- film_category
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from film_category"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from film_category")
query="insert into film_category values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[14]:


#DVDSTAGING- inventory
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from inventory"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from inventory")
query="insert into inventory values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[15]:


#DVDSTAGING- staff
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from staff"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from staff")
query="insert into staff values(?,?,?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[16]:


#DVDSTAGING- address
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from address"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from address")
query="insert into address values(?,?,?,?,?.?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[18]:


#DVDSTAGING- address
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD2',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD2")
sql="select * from address"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from address")
query="insert into address values(?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[19]:


#DVDSTAGING- CUSTOMER
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD3',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD3")
sql="select * from customer"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from customer")
query="insert into customer values(?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[20]:


#DVDSTAGING- film_actor
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD3',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD3")
sql="select * from film_actor"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from film_actor")
query="insert into film_actor values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[21]:


#DVDSTAGING- rental
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD3',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD3")
sql="select * from rental"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from rental")
query="insert into rental values(?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[24]:


#DVDSTAGING- payment
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD3',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD3")
sql="select * from payment"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from payment")
query="insert into payment values(?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[25]:


#DVDSTAGING- store
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='SLCDVD3',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use SLCDVD3")
sql="select * from store"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDSTAGING")
cursor.execute("delete from store")
query="insert into store values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[26]:


import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from actor"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from actor")
query="insert into ACTOR values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[27]:


#DVDDW- CATEGORY
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from category"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from category")
query="insert into category values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[28]:


#DVDDW- City
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from city"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from city")
query="insert into city values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()



# In[29]:


#DVDDW- Country
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from country"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from country")
query="insert into country values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[30]:


#DVDDW- Language

import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from language"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from language")
query="insert into language values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[31]:


#DVDDW- film
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from film"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from film")
query="insert into film values(?,?,?,?,?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[32]:


#DVDDW- film_category
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from film_category"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from film_category")
query="insert into film_category values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[33]:


#DVDDW- inventory
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from inventory"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from inventory")
query="insert into inventory values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[34]:


#DVDDW- staff
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from staff"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from staff")
query="insert into staff values(?,?,?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[36]:


#DVDDW- address

import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from address"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from address")
query="insert into address values(?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[37]:


#DVDDW- CUSTOMER
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from customer"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from customer")
query="insert into customer values(?,?,?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[38]:


#DVDDW- film_actor
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from film_actor"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from film_actor")
query="insert into film_actor values(?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[39]:


#DVDDW- rental
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from rental"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from rental")
query="insert into rental values(?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[40]:


#DVDDW- payment
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from payment"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from payment")
query="insert into payment values(?,?,?,?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[41]:


#DVDDW- store
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(driver='{SQL Server}',server='DESKTOP-UKA5IHV',database='DVDSTAGING',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use DVDSTAGING")
sql="select * from store"
df=psql.read_sql_query(sql,cnxn)
cursor.commit()
df1=df.values.tolist()
print(df1)
cursor.execute("use DVDDW")
cursor.execute("delete from store")
query="insert into store values(?,?,?,?)"
cursor.executemany(query,df1)
cursor.commit()
print("row inserted")
cnxn.close()


# In[ ]:




