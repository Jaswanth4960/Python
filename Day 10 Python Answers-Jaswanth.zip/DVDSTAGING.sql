create table actor (
	actor_id int ,
    first_name varchar(100),
    last_name varchar(100),
    last_update datetime,
)


create table category (
	category_id int,
    name varchar(50),
    last_update datetime,
)


create table language (
	language_id int,
    name varchar(50),
    last_update datetime,
)



create table country(
	country_id int,
    country_name varchar(255),
    last_update datetime
);


create table city (
	city_id int,
    city_name varchar(255),
    country_id int,
    last_update datetime
);

create table film (
	film_id int,
	title varchar(255),
	description text,
	release_year INT,
	language_id int,
	original_language_id int,
	rental_duration int,
	rental_rate float,
	length int,
	replacement_cost float,
	rating varchar(50),
	special_features text,
	last_update DATETIME,
);



create table film_category(
	film_id int,
    category_id int,
    last_update DATETIME
);


create table address(
	address_id int,
    address text,
    address2 text,
    district varchar(255),
    city_id int,
    postal_code varchar(255),
    phone varchar(255),
    last_update DATETIME
);



create table inventory (
	inventory_id int,
    film_id int,
    store_id int,
    last_update DATETIME);


create table staff (
	staff_id int,
    first_name varchar(100),
    last_name varchar(100),
    address_id int,
    picture varchar(255),
    email varchar(100),
    store_id int,
    active int,
    username varchar(100),
    password varchar(100),
    last_update DATETIME,
)

create table store (
	store_id int,
    manager_staff_id int,
    address_id int,
    last_update DATETIME
);

create table customer(
	customer_id int,
    store_id int,
    first_name varchar(100),
    last_name varchar(100),
    email varchar(100),
    address_id int,
    active int,
    create_date DATETIME,
    last_update DATETIME
   
);

create table rental (
	rental_id int,
    rental_date DATETIME,
    inventory_id int,
    customer_id int,
    return_date DATETIME,
    staff_id int,
    last_update DATETIME
);

create table payment(
	payment_id int,
    customer_id int,
    staff_id int,
    rental_id varchar(200),
    amount float,
    payment_date DATETIME,
    last_update DATETIME
);

create table film_actor(
	actor_id int,
    film_id int,
    last_update DATETIME
);





