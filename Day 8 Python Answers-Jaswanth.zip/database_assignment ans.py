
#1.How do you update data from  python using sqlserver table?
'''
import pyodbc
cnxn=pyodbc.connect(DRIVER='{SQL Server}',server='DESKTOP-UKA5IHV',database='jaswanth',trustedconnection='yes')
cursor=cnxn.cursor()
sql='update EMP set COMM=100 where EMPNO=7369'
cursor.execute(sql)
cursor.execute('COMMIT')
print("Updated Successfully")
print(cursor.rowcount," rows are effected")
cnxn.close()
'''

#2.How do you run a select query in Python?
'''
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(DRIVER='{SQL Server}',server='DESKTOP-UKA5IHV',database='jaswanth',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("use jaswanth")
sql="select * from emp"
df=psql.read_sql_query(sql,cnxn)
print(df)
cnxn.close()
'''

#3.How do you import a database in Python?
'''
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(DRIVER="{SQL Server}",server='DESKTOP-UKA5IHV',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute('use jaswanth')
print("Imported Database Successfully")
sql='select * from sys.tables'
df=psql.read_sql_query(sql,cnxn)
print(df)
cnxn.close()
'''


#4.How do you insert data into a python using sqlserver table?
'''
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(DRIVER="{SQL Server}",server='DESKTOP-UKA5IHV',database='jaswanth',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("insert into emp (EMPNO,ENAME,JOB) values(8000,'JASWANTH','ANALYST')")
cursor.commit()
print(cursor.rowcount," rows affected ")
cnxn.close()
'''


#5.How do you delete data from python using sqlserver table?
import pyodbc
import pandas.io.sql as psql
cnxn=pyodbc.connect(DRIVER="{SQL Server}",server='DESKTOP-UKA5IHV',database='jaswanth',trustedconnection='yes')
cursor=cnxn.cursor()
cursor.execute("delete from emp where ename='JASWANTH'")
cursor.commit()
print(cursor.rowcount," rows affected")
cnxn.close()



