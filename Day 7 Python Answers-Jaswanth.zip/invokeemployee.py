from employee.emp import Emp
from employee.dept import Dept
from employee.salgrade import Salgrade

obj1=Emp()
obj2=Dept()
obj3=Salgrade()
obj1.getdetails()
obj2.getdata()
obj3.getsal()
