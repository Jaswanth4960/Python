from sound.load import load
from sound.play import play
from sound.pause import pause
from image.open import open
from image.change import change
from image.close import close
from level.start import start
from level.loadlevel import loadlevel
from level.over import over
obj1=load()
obj1.printLoad()
obj2=play()
obj2.printPlay()
obj3=pause()
obj3.printPause()
obj4=open()
obj4.printOpen()
obj5=change()
obj5.printChange()
obj6=close()
obj6.printClose()
obj7=start()
obj7.printStart()
obj8=loadlevel()
obj8.printLoadLevel()
obj9=over()
obj9.printOver()
