'''
import datetime
print("Current date and time: " , datetime.datetime.now())
print("Current year: ", datetime.date.today().strftime("%Y"))
print("Month of year: ", datetime.date.today().strftime("%B"))
print("Week number of the year: ", datetime.date.today().strftime("%W"))
print("Weekday of the week: ", datetime.date.today().strftime("%w"))
print("Day of year: ", datetime.date.today().strftime("%j"))
print("Day of the month : ", datetime.date.today().strftime("%d"))
print("Day of week: ", datetime.date.today().strftime("%A"))
'''
#leap year
'''
import calendar
import datetime
year=int(datetime.date.today().strftime("%Y"))
if calendar.isleap(year):
    print(year," is a leap year")
else:
    print(year," is not a leap year")
'''
'''
import calendar
year=int(input("Enter Year :"))
if calendar.isleap(year):
    print(year," is a leap year")
else:
    print(year," is not a leap year")
'''
#String to Date
'''
from dateutil import parser
str=input
DT = parser.parse(str)
print(DT)
'''
'''
import datetime
def varToDate(s):
    format_str= '%b %d %Y %I:%M%p'
    date_time=datetime.datetime.strptime(s,format_str)
    return date_time
s=input("Enter String Date :")
print(varToDate(s))
'''
'''
import datetime
t=datetime.datetime.now()
present_time=t.strftime("%H:%M:%S.%f")
print(present_time)
'''
#5 days before
'''
from datetime import date,timedelta
s=date.today()
dt=s-timedelta(5)
print(dt)
'''
'''
from datetime import date, datetime
dt=input("Enter Date (yyyy-mm-dd)")
l=dt.split('-')
date_object = date(int(l[0]),l[1],l[2])

# Convert date to datetime
datetime_object = datetime.combine(date_object, datetime.min.time())

print(datetime_object)
'''
#5 secs after
'''
import datetime
t=datetime.datetime.now()
x=t+datetime.timedelta(0,5)
print(t.time())
print(x.time())
'''
#WeekNumber
'''
import datetime
year=int(input("Enter Year :"))
month=int(input("Enter Month :"))
day=int(input("Enter Day :"))
d=datetime.date(year,month,day).isocalendar().week
print(d)
'''
#First Monday of WeekNumber
'''
import time
year=int(input("Enter year :"))
wn=int(input("Enter WeekNumber :"))
v=str(year)+' '+str(wn)+' '+'1'
print(time.asctime(time.strptime(v, '%Y %W %w')))
'''
#Difference b/n dates
'''
import datetime
year=int(input("Enter Year :"))
month=int(input("Enter Month :"))
day=int(input("Enter Day :"))
d1=datetime.date(year,month,day)
print(d1)
year=int(input("Enter Year :"))
month=int(input("Enter Month :"))
day=int(input("Enter Day :"))
d2=datetime.date(year,month,day)
print(d2)
n=abs(d1-d2)
print("Difference :",n)
'''
#Get Date of Last Tuesday
'''
from datetime import date
from datetime import timedelta
today = date.today()
offset = (today.weekday() - 1) % 7
last_tuesday = today - timedelta(offset)
print(last_tuesday)
'''
#Third Tuesday
'''
import datetime
year=int(input("Enter Year :"))
month=int(input("Enter Month :"))
st=datetime.date(year,month,1)
end=datetime.date(year,month,28)
c=0
while st<end:
    if st.weekday()==1:
        c+=1
        if c==3:
            print("Date :",st)
        st=st+datetime.timedelta(1)
    else:
        st=st+datetime.timedelta(1)
'''
#Last day of specific month
'''
import datetime
year=int(input("Enter Year :"))
month=int(input("Enter Month :"))
month=month+1
dt=datetime.date(year,month,1)
d=dt-datetime.timedelta(1)
print(d)
print(d.strftime("%A"))
'''
#no of days of given month and year
'''
import datetime
year=int(input("Enter Year :"))
month=int(input("Enter month :"))
d1=datetime.date(year,month,1)
month+=1
d2=datetime.date(year,month,1)
d3=d2-datetime.timedelta(1)
count=abs(d1.day-d3.day)+1
print(count)
'''
#no of mondays from  1st of 2021 to end of 2022
'''
import datetime
st=datetime.date(2021,1,1)
end=datetime.date(2022,12,31)
count=0
while st<=end:
    if st.weekday()==0:
        count+=1
        st=st+datetime.timedelta(1)
    else:
        st=st+datetime.timedelta(1)
print("No of Mondays :",count)
'''
#Current Week
'''
import datetime
n=datetime.date.today().strftime("%W")
print("Week no :"n)
'''
#Exception
'''
oldread=int(input("Enter Old Reading :"))
newread=int(input("Enter New Reading :"))
try:
    if newread<oldread:
        raise InvalidUnits
    else:
        units=newread-oldread
        print("No of units :",units)
except InvalidUnits:
    print("Invalid Units")
'''
    

    
        












    
    
