from tkinter import *
import pyodbc
import pandas.io.sql as psql
from datetime import datetime,date
from tkinter import messagebox

w=Tk()
w.title('Bank Transactions')

cname=Label(w,text='Customer Name: ')
cname.grid(row=0,column=0)
cname_txtbx=Entry(w,width=50)
cname_txtbx.grid(row=0,column=1)

acc=Label(w,text='Account Number: ')
acc.grid(row=1,column=0)
acc_txtbx=Entry(w,width=50)
acc_txtbx.grid(row=1,column=1)

ttype=Label(w,text='Transaction Type: ')
ttype.grid(row=2,column=0)
ttype_txtbx=Entry(w,width=50)
ttype_txtbx.grid(row=2,column=1)

tdate=Label(w,text='Transaction Date: ')
tdate.grid(row=3,column=0)
tdate_txtbx=Entry(w,width=50)
tdate_txtbx.grid(row=3,column=1)

amt=Label(w,text='Amount: ')
amt.grid(row=4,column=0)
amt_txtbx=Entry(w,width=50)
amt_txtbx.grid(row=4,column=1)

def Amt():
    cnxn=pyodbc.connect(driver='{SQL SERVER}',server='DESKTOP-UKA5IHV',database='jaswanth',trustedconnection='yes')
    c=cnxn.cursor()
    c.execute("use jaswanth")
    cn=cname_txtbx.get()
    accno=int(acc_txtbx.get())
    tty=ttype_txtbx.get()
    std=tdate_txtbx.get()
    std_obj=datetime.strptime(std,'%Y-%m-%d').date()
    td=std_obj.strftime("%Y-%m-%d")
    amut=int(amt_txtbx.get())
    print("insert into bankmaster(cname,accno,ttype,tdate,amount) values ("+"'"+cn+"'"+','+str(accno)+','+"'"+tty+"'"+','+"'"+td+"'"+','+str(amut)+")")
    c.execute("insert into bankmaster(cname,accno,ttype,tdate,amount) values("+"'"+cn+"'"+','+str(accno)+','+"'"+tty+"'"+','+"'"+td+"'"+','+str(amut)+")")
    c.commit();
    r=str(c.rowcount) + ' row inserted'
    messagebox.showinfo("Inserted",r)
    sql="SELECT * FROM BANKMASTER"
    d=psql.read_sql_query(sql,cnxn)
    print(d)
    cnxn.close()
    
Amt_button=Button(w,text="Insert",command=Amt)
Amt_button.grid(row=5,column=1,columnspan=2)
    
w.geometry('400x300')
w.mainloop()
