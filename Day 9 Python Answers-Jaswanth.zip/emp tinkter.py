from tkinter import *
window=Tk()
window.title('Employee Salary Calculator')
label=Label(window,text='Employee Salary Calculator',font="Helvetica 16 bold ")
label.grid(row=0,column=0)
label2=Label(window,text='Employee Name ')
label2.grid(row=1,column=0)
en1=Entry(window,width=30)
en1.grid(row=1,column=1)
label2=Label(window,text='Employee Number')
label2.grid(row=2,column=0)
en2=Entry(window,width=30)
en2.grid(row=2,column=1)
label3=Label(window,text='Salary ')
label3.grid(row=3,column=0)
en3=Entry(window,width=20)
en3.grid(row=3,column=1)
en4=Entry(window)
en4.grid(row=4,column=0)
label5=Label(window,text='HRA',font='Helvetica 16 bold')
label5.grid(row=5,column=0)
en5=Entry(window)
en5.grid(row=4,column=1)
label5=Label(window,text='MA',font='Helvetica 16 bold')
label5.grid(row=5,column=1)
en6=Entry(window)
en6.grid(row=4,column=2)
label6=Label(window,text='TA',font='Helvetica 16 bold')
label6.grid(row=5,column=2)
en7=Entry(window)
en7.grid(row=4,column=4)
label7=Label(window,text='PF',font='Helvetica 16 bold')
label7.grid(row=5,column=4)
en8=Entry(window)
en8.grid(row=6,column=1)
label8=Label(window,text='Gross Pay',font='Helvetica 16 bold')
label8.grid(row=7,column=1)
en9=Entry(window)
en9.grid(row=6,column=3)
label7=Label(window,text='Net Pay',font='Helvetica 16 bold')
label7.grid(row=7,column=3)


def insertSal():
    sal=int(en3.get())
    en4.insert(0,int(0.5*sal))
    hra=int(en4.get())
    en5.insert(0,int(0.21*sal))
    ma=int(en5.get())
    en6.insert(0,int(0.18*sal))
    ta=int(en6.get())
    en7.insert(0,int(0.37*sal))
    pf=int(en7.get())
    en8.insert(0,int(sal+hra+ma+ta))
    gp=int(en8.get())
    en9.insert(0,gp-pf)
    
    
   

btn1=Button(window,text='Calculate',command=insertSal)
btn1.grid(row=8,column=1)
    


















window.mainloop()

