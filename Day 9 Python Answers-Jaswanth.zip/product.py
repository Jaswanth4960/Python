from tkinter import *
w=Tk()
w.title('Product List')

pname = Label(w,text='Product Name: ')
pname.grid(row=0,column=0)
pname_txtbx=Entry(w,width=50)
pname_txtbx.grid(row=0,column=1)

pid = Label(w,text='Product Id: ')
pid.grid(row=1,column=0)
pid_txtbx=Entry(w,width=50)
pid_txtbx.grid(row=1,column=1)

qty=Label(w,text='Quantity: ')
qty.grid(row=2,column=0)
qty_txtbx=Entry(w,width=50)
qty_txtbx.grid(row=2,column=1)

rate=Label(w,text='Product Rate: ')
rate.grid(row=3,column=0)
rate_txtbx=Entry(w,width=50)
rate_txtbx.grid(row=3,column=1)

amt=Label(w,text='Total Amount: ')
amt.grid(row=4,column=0)
amt_txtbx=Entry(w,width=50)
amt_txtbx.grid(row=4,column=1)

def amount():
    amt_txtbx.delete(0,END)
    quty=float(qty_txtbx.get())
    rt=float(rate_txtbx.get())
    amount=rt*quty
    amt_txtbx.insert(0,amount)

space=Label(w,text="") 
space.grid(row=5,column=0)

calAtButton=Button(w,text='Total',command=amount)
calAtButton.grid(row=6,column=1)

w.geometry('400x300')
w.mainloop()
